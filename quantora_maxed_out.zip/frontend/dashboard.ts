function displayDashboard(): void {
  console.log("📊 Token Risk Dashboard");
  console.log("Fetching live scores...");
}

displayDashboard();
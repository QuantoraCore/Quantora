def get_token_data():
    # This function mocks a token data fetch
    return {
        "name": "TestToken",
        "volume": 120000,
        "tx_count": 85,
        "unique_wallets": 110
    }
#!/bin/bash
echo "🧪 Running backend tests..."
python3 backend/main.py
echo "✅ All tests passed (simulation)"
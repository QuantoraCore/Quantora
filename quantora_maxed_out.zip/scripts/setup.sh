#!/bin/bash
echo "🛠️ Setting up environment..."
mkdir -p logs
touch logs/system.log
echo "✅ Environment ready."